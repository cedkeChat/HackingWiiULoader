#pragma once

#include "../utils/logger.h"
#include "../common/common.h"
#include "../fs/CFile.hpp"

#define IP_TXT "ip.txt"

void initializeUDPLog();